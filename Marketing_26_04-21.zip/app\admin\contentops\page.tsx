"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { LoadingOverlay } from "@/components/contentops/loading-overlay";

type IncomingFile = {
  id: string;
  name: string;
  mimeType: string;
  webViewLink?: string | null;
};

function extLabel(name: string): string {
  const parts = name.split(".");
  if (parts.length < 2) return "FILE";
  return parts.at(-1)?.slice(0, 6).toUpperCase() || "FILE";
}

export default function ContentOpsInboxPage() {
  const [files, setFiles] = useState<IncomingFile[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async (mode: "initial" | "refresh" = "initial") => {
    if (mode === "refresh") setRefreshing(true);
    else setLoading(true);

    setError(null);
    try {
      const res = await fetch("/api/contentops/incoming", { credentials: "include" });
      const data = await res.json();
      if (!res.ok) {
        setError((data as { error?: string }).error ?? "Failed to load");
        setFiles([]);
        return;
      }
      setFiles((data as { files: IncomingFile[] }).files ?? []);
    } catch {
      setError("Network error");
      setFiles([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    void load("initial");
  }, [load]);

  return (
    <main className="co-stack" style={{ padding: "1.25rem", position: "relative" }}>
      <LoadingOverlay open={refreshing} text="Loading..." fullscreen />

      <div className="co-row" style={{ justifyContent: "space-between", width: "100%" }}>
        <h1 style={{ margin: 0 }}>Incoming (Google Drive)</h1>
        <button type="button" className="co-btn" onClick={() => void load("refresh")} disabled={loading || refreshing}>
          Refresh
        </button>
      </div>
      <p className="co-muted">
        Files listed here are already in Drive — nothing is uploaded through Vercel. Select them when creating a{" "}
        <Link href="/admin/contentops/new">new post</Link>.
      </p>

      {error ? <p style={{ color: "var(--danger)" }}>{error}</p> : null}

      {loading ? (
        <section className="co-panel co-stack" style={{ minHeight: 220, justifyContent: "center", position: "relative" }}>
          <LoadingOverlay open text="Loading incoming files..." />
          <div className="co-grid" aria-hidden="true">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="co-thumb co-skeleton" />
            ))}
          </div>
        </section>
      ) : null}

      {!loading && files && files.length === 0 ? <p className="co-muted">No files in the incoming folder.</p> : null}

      {!loading ? (
        <div className="co-grid">
          {(files ?? []).map((f) => (
            <div key={f.id} className="co-thumb">
              {f.mimeType.startsWith("image/") ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={`/api/contentops/drive/file?id=${encodeURIComponent(f.id)}`} alt={f.name} />
              ) : (
                <div className="co-file-placeholder">{extLabel(f.name)}</div>
              )}
              <div style={{ padding: "0.35rem 0.5rem", fontSize: "0.8rem" }}>
                <div style={{ wordBreak: "break-word" }}>{f.name}</div>
                {f.webViewLink ? (
                  <a href={f.webViewLink} target="_blank" rel="noreferrer">
                    Open in Drive
                  </a>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      ) : null}
    </main>
  );
}