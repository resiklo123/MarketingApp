import path from "node:path";
import { PostStatus, type Prisma } from "@prisma/client";
import { defaultCtaUrl } from "@/lib/contentops-constants";
import {
  createShortcut,
  ensureByDatePostFolder,
  ensurePostFolder,
  getFileMetadata,
  moveAndRenameFile,
  sanitizePathSegment,
} from "@/lib/google-drive";
import { generateDraftsJson, type DraftsJson } from "@/lib/openai-drafts";
import { prisma } from "@/lib/prisma";
import { getOptionalRedis } from "@/lib/redis";
import { sendTelegramDraftReadyMessage } from "@/lib/telegram";

function modelSlug(value?: string | null): string {
  if (!value) return "";
  return sanitizePathSegment(value)
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 24)
    .replace(/^[-_]+|[-_]+$/g, "")
    .toLowerCase();
}

function buildFinalName(postId: string, machineModel: string | null | undefined, originalName: string): string {
  const ext = path.extname(originalName);
  const base = path.basename(originalName, ext).replace(/[/\\?%*:|"'<>]/g, "-").slice(0, 96);
  const slug = modelSlug(machineModel);
  return `${postId}_${slug ? `${slug}_` : ""}${base || "asset"}${ext}`;
}

function stubDraftsJson(): DraftsJson {
  return {
    fb: { caption: "TEST_MODE Facebook caption", hashtags: "#resiklo #test" },
    ig: { caption: "TEST_MODE Instagram caption", hashtags: "#resiklo #test" },
    tiktok: { caption: "TEST_MODE TikTok caption", hashtags: "#resiklo #test" },
    youtube: { title: "TEST_MODE YouTube title", description: "TEST_MODE YouTube description" },
    website: { snippet: "TEST_MODE website snippet" },
  };
}

function draftCreatesFromJson(postId: string, platforms: string[], data: DraftsJson): Prisma.DraftCreateManyInput[] {
  const rows: Prisma.DraftCreateManyInput[] = [];
  const upper = new Set(platforms.map((p) => p.toUpperCase()));

  if (upper.has("FB")) rows.push({ postId, platform: "FB", caption: data.fb.caption, hashtags: data.fb.hashtags, version: 1 });
  if (upper.has("IG")) rows.push({ postId, platform: "IG", caption: data.ig.caption, hashtags: data.ig.hashtags, version: 1 });
  if (upper.has("TIKTOK")) {
    rows.push({ postId, platform: "TIKTOK", caption: data.tiktok.caption, hashtags: data.tiktok.hashtags, version: 1 });
  }
  if (upper.has("YOUTUBE")) {
    rows.push({ postId, platform: "YOUTUBE", title: data.youtube.title, description: data.youtube.description, version: 1 });
  }
  if (upper.has("WEBSITE")) rows.push({ postId, platform: "WEBSITE", caption: data.website.snippet, version: 1 });

  return rows;
}

export async function processNewContentOpsPost(input: {
  machineFamily: string;
  machineModel?: string | null;
  topic: string;
  location?: string | null;
  platforms: string[];
  driveFileIds: string[];
}): Promise<{ postId: string }> {
  const testMode = process.env.CONTENTOPS_TEST_MODE === "true";
  const redis = getOptionalRedis();
  void redis?.incr("contentops:posts_created").catch(() => undefined);

  const normalizedFamily = sanitizePathSegment(input.machineFamily);
  const normalizedModel = input.machineModel?.trim() ? sanitizePathSegment(input.machineModel) : null;

  const post = await prisma.post.create({
    data: {
      machine: normalizedFamily,
      machineFamily: normalizedFamily,
      machineModel: normalizedModel,
      topic: input.topic,
      location: input.location ?? null,
      platforms: input.platforms.map((p) => p.toUpperCase()),
      status: PostStatus.PROCESSING,
    },
  });

  try {
    if (testMode) {
      await prisma.asset.createMany({
        data: input.driveFileIds.map((driveFileId, i) => ({
          postId: post.id,
          driveFileId,
          originalName: `test-asset-${i + 1}.jpg`,
          finalName: buildFinalName(post.id, normalizedModel, `test-asset-${i + 1}.jpg`),
          mimeType: "image/jpeg",
          size: null,
          webViewLink: null,
          thumbnailLink: null,
        })),
      });

      const draftRows = draftCreatesFromJson(post.id, input.platforms, stubDraftsJson());
      if (draftRows.length) await prisma.draft.createMany({ data: draftRows });

      await prisma.post.update({ where: { id: post.id }, data: { status: PostStatus.DRAFT_READY } });
      return { postId: post.id };
    }

    const metas = await Promise.all(input.driveFileIds.map((id) => getFileMetadata(id)));
    const canonicalFolderId = await ensurePostFolder({
      id: post.id,
      machineFamily: normalizedFamily,
      machineModel: normalizedModel,
      topic: input.topic,
      createdAt: post.createdAt,
    });

    const moved: { meta: (typeof metas)[0]; finalName: string; afterMove: Awaited<ReturnType<typeof moveAndRenameFile>> }[] = [];
    for (const meta of metas) {
      const finalName = buildFinalName(post.id, normalizedModel, meta.name);
      const afterMove = await moveAndRenameFile(meta.id, canonicalFolderId, finalName);
      moved.push({ meta, finalName, afterMove });
    }

    await prisma.asset.createMany({
      data: moved.map(({ meta, finalName, afterMove }) => ({
        postId: post.id,
        driveFileId: afterMove.id ?? meta.id,
        originalName: meta.name,
        finalName,
        mimeType: afterMove.mimeType ?? meta.mimeType,
        size: afterMove.size != null ? BigInt(afterMove.size) : meta.size != null ? BigInt(meta.size) : null,
        webViewLink: afterMove.webViewLink ?? meta.webViewLink ?? null,
        thumbnailLink: afterMove.thumbnailLink ?? meta.thumbnailLink ?? null,
      })),
    });

    const year = post.createdAt.getUTCFullYear().toString();
    const month = String(post.createdAt.getUTCMonth() + 1).padStart(2, "0");
    const byDatePostFolderId = await ensureByDatePostFolder(year, month, post.id);
    await createShortcut(byDatePostFolderId, canonicalFolderId, `${post.id}__POST_FOLDER`);
    for (const { meta, afterMove } of moved) {
      const targetId = afterMove.id ?? meta.id;
      await createShortcut(byDatePostFolderId, targetId, `${post.id}__${meta.name}`);
    }

    const draftsJson = await generateDraftsJson({
      machine: normalizedModel ? `${normalizedFamily} ${normalizedModel}` : normalizedFamily,
      topic: input.topic,
      location: input.location,
      ctaUrl: defaultCtaUrl(),
      platforms: input.platforms.map((p) => p.toUpperCase()),
    });

    const draftRows = draftCreatesFromJson(post.id, input.platforms, draftsJson);
    if (draftRows.length) await prisma.draft.createMany({ data: draftRows });

    await prisma.post.update({ where: { id: post.id }, data: { status: PostStatus.DRAFT_READY } });

    try {
      await sendTelegramDraftReadyMessage({
        postId: post.id,
        machine: normalizedModel ? `${normalizedFamily}/${normalizedModel}` : normalizedFamily,
        topic: input.topic,
      });
    } catch (e) {
      console.error("[contentops] Telegram notify failed (post still DRAFT_READY):", e);
    }

    return { postId: post.id };
  } catch (e) {
    await prisma.post.update({ where: { id: post.id }, data: { status: PostStatus.FAILED } });
    throw e;
  }
}