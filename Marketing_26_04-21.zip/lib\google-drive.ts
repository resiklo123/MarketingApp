import { google, drive_v3 } from "googleapis";

export type IncomingDriveFile = {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  createdTime?: string | null;
  webViewLink?: string | null;
  thumbnailLink?: string | null;
};

function parseServiceAccountJson(raw: string | undefined): object {
  if (!raw || !raw.trim()) {
    throw new Error("GOOGLE_SERVICE_ACCOUNT_JSON is empty");
  }
  const trimmed = raw.trim();
  try {
    return JSON.parse(trimmed) as object;
  } catch {
    try {
      const unescaped = JSON.parse(`"${trimmed.replace(/"/g, '\\"')}"`) as string;
      return JSON.parse(unescaped) as object;
    } catch {
      throw new Error("GOOGLE_SERVICE_ACCOUNT_JSON is not valid JSON");
    }
  }
}

export function getDriveClient(): drive_v3.Drive {
  const credentials = parseServiceAccountJson(process.env.GOOGLE_SERVICE_ACCOUNT_JSON);
  const auth = new google.auth.GoogleAuth({
    credentials,
    scopes: ["https://www.googleapis.com/auth/drive"],
  });
  return google.drive({ version: "v3", auth });
}

export function sanitizePathSegment(segment: string): string {
  return segment
    .replace(/[/\\?%*:|"'<>]/g, "-")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 200) || "unnamed";
}

function folderQuery(parentId: string, mimeType?: string, name?: string): string {
  const q = [`'${parentId}' in parents`, "trashed = false"];
  if (mimeType) q.push(`mimeType = '${mimeType}'`);
  if (name) q.push(`name = '${name.replace(/'/g, "\\'")}'`);
  return q.join(" and ");
}

export async function listIncomingFiles(limit = 50): Promise<IncomingDriveFile[]> {
  const folderId = process.env.DRIVE_INCOMING_FOLDER_ID;
  if (!folderId) throw new Error("DRIVE_INCOMING_FOLDER_ID is not set");
  const drive = getDriveClient();
  const res = await drive.files.list({
    q: `'${folderId}' in parents and trashed = false and mimeType != 'application/vnd.google-apps.folder'`,
    pageSize: limit,
    fields: "nextPageToken, files(id, name, mimeType, size, createdTime, webViewLink, thumbnailLink)",
    supportsAllDrives: true,
    includeItemsFromAllDrives: true,
  });
  return (res.data.files ?? []).map((f) => ({
    id: f.id!,
    name: f.name ?? "",
    mimeType: f.mimeType ?? "",
    size: f.size ?? undefined,
    createdTime: f.createdTime,
    webViewLink: f.webViewLink,
    thumbnailLink: f.thumbnailLink,
  }));
}

async function findOrCreateFolder(drive: drive_v3.Drive, name: string, parentId: string): Promise<string> {
  const safe = sanitizePathSegment(name);
  const existing = await drive.files.list({
    q: folderQuery(parentId, "application/vnd.google-apps.folder", safe),
    pageSize: 1,
    fields: "files(id, name)",
    supportsAllDrives: true,
    includeItemsFromAllDrives: true,
  });
  const hit = existing.data.files?.[0];
  if (hit?.id) return hit.id;

  const created = await drive.files.create({
    requestBody: {
      name: safe,
      mimeType: "application/vnd.google-apps.folder",
      parents: [parentId],
    },
    fields: "id",
    supportsAllDrives: true,
  });
  if (!created.data.id) throw new Error(`Failed to create folder: ${safe}`);
  return created.data.id;
}

function normalizeMachineFamily(machineFamily: string): string {
  const normalized = sanitizePathSegment(machineFamily);
  if (/^baler(s)?$/i.test(normalized)) return "Balers";
  return normalized;
}

export type PostFolderContext = {
  id: string;
  machineFamily: string;
  machineModel?: string | null;
  topic: string;
  createdAt: Date;
};

export async function ensurePostFolder(post: PostFolderContext): Promise<string> {
  const libraryId = process.env.DRIVE_LIBRARY_FOLDER_ID;
  if (!libraryId) throw new Error("DRIVE_LIBRARY_FOLDER_ID is not set");
  const drive = getDriveClient();
  const y = post.createdAt.getUTCFullYear().toString();
  const m = String(post.createdAt.getUTCMonth() + 1).padStart(2, "0");
  const family = normalizeMachineFamily(post.machineFamily);
  const model = sanitizePathSegment(post.machineModel?.trim() || "_General");
  const topic = sanitizePathSegment(post.topic);

  const familyId = await findOrCreateFolder(drive, family, libraryId);
  const modelId = await findOrCreateFolder(drive, model, familyId);
  const yearId = await findOrCreateFolder(drive, y, modelId);
  const monthId = await findOrCreateFolder(drive, m, yearId);
  const topicId = await findOrCreateFolder(drive, topic, monthId);
  return findOrCreateFolder(drive, post.id, topicId);
}

export async function ensureByDatePostFolder(year: string, month: string, postId: string): Promise<string> {
  const libraryId = process.env.DRIVE_LIBRARY_FOLDER_ID;
  if (!libraryId) throw new Error("DRIVE_LIBRARY_FOLDER_ID is not set");
  const drive = getDriveClient();

  const byDateId = await findOrCreateFolder(drive, "_ByDate", libraryId);
  const yearId = await findOrCreateFolder(drive, year, byDateId);
  const monthId = await findOrCreateFolder(drive, month, yearId);
  return findOrCreateFolder(drive, postId, monthId);
}

export async function createShortcut(parentFolderId: string, targetId: string, name: string): Promise<string> {
  const drive = getDriveClient();
  const shortcutName = sanitizePathSegment(name);

  const existing = await drive.files.list({
    q: folderQuery(parentFolderId, "application/vnd.google-apps.shortcut", shortcutName),
    pageSize: 10,
    fields: "files(id, name, shortcutDetails/targetId)",
    supportsAllDrives: true,
    includeItemsFromAllDrives: true,
  });

  const sameTarget = existing.data.files?.find((f) => f.shortcutDetails?.targetId === targetId) ?? existing.data.files?.[0];
  if (sameTarget?.id) return sameTarget.id;

  const created = await drive.files.create({
    requestBody: {
      name: shortcutName,
      mimeType: "application/vnd.google-apps.shortcut",
      parents: [parentFolderId],
      shortcutDetails: { targetId },
    },
    fields: "id",
    supportsAllDrives: true,
  });

  if (!created.data.id) throw new Error(`Failed creating shortcut ${shortcutName}`);
  return created.data.id;
}

export async function moveAndRenameFile(
  fileId: string,
  newParentId: string,
  newName: string,
): Promise<drive_v3.Schema$File> {
  const drive = getDriveClient();
  const meta = await drive.files.get({
    fileId,
    fields: "parents",
    supportsAllDrives: true,
  });
  const prevParents = (meta.data.parents ?? []).join(",");
  const updated = await drive.files.update({
    fileId,
    addParents: newParentId,
    removeParents: prevParents || undefined,
    requestBody: { name: sanitizePathSegment(newName) },
    fields: "id, name, mimeType, size, webViewLink, thumbnailLink, parents",
    supportsAllDrives: true,
  });
  return updated.data;
}

export async function getFileMetadata(fileId: string): Promise<IncomingDriveFile> {
  const drive = getDriveClient();
  const res = await drive.files.get({
    fileId,
    fields: "id, name, mimeType, size, createdTime, webViewLink, thumbnailLink",
    supportsAllDrives: true,
  });
  const f = res.data;
  return {
    id: f.id!,
    name: f.name ?? "",
    mimeType: f.mimeType ?? "",
    size: f.size ?? undefined,
    createdTime: f.createdTime,
    webViewLink: f.webViewLink,
    thumbnailLink: f.thumbnailLink,
  };
}