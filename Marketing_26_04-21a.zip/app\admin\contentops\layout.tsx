import { ContentOpsAuthShell } from "@/components/contentops/auth-shell";
import { ContentOpsNavLinks } from "@/components/contentops/nav-links";

export default function ContentOpsLayout({ children }: { children: React.ReactNode }) {
  return (
    <ContentOpsAuthShell>
      <header
        style={{
          borderBottom: "1px solid var(--border)",
          background: "var(--panel)",
        }}
      >
        <div
          style={{
            maxWidth: 1100,
            margin: "0 auto",
            padding: "0.75rem 1.25rem",
            display: "flex",
            gap: "1rem",
            flexWrap: "wrap",
            alignItems: "center",
          }}
        >
          <strong>ContentOps</strong>
          <ContentOpsNavLinks />
        </div>
      </header>
      <main style={{ maxWidth: 1100 }}>{children}</main>
    </ContentOpsAuthShell>
  );
}
