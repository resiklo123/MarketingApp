import { NextResponse } from "next/server";
import { assertContentOpsRequest } from "@/lib/contentops-auth";
import { prisma } from "@/lib/prisma";

export async function GET(request: Request) {
  try {
    await assertContentOpsRequest(request);
  } catch (e) {
    const code = (e as Error & { statusCode?: number }).statusCode;
    if (code === 401) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }

  const url = new URL(request.url);
  const family = url.searchParams.get("family")?.trim();
  if (!family) return NextResponse.json({ models: [] });

  const rows = await prisma.machineModelOption.findMany({
    where: { family, isActive: true },
    orderBy: { model: "asc" },
    select: { model: true },
  });

  return NextResponse.json({ models: rows.map((r) => r.model) });
}
