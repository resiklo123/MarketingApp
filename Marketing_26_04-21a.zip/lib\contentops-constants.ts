export const MACHINE_FAMILY_OPTIONS = [
  "Balers",
  "Shredder",
  "Granulator",
  "Extrusion line",
  "Wash line",
  "Pelletizer",
  "Other",
] as const;

export const MACHINE_OPTIONS = MACHINE_FAMILY_OPTIONS;

export const BALER_MODEL_OPTIONS = ["RHB-5T", "RHB-10T", "RHB-20T", "Other"] as const;

export const TOPIC_OPTIONS = [
  "Process spotlight",
  "Safety",
  "Customer story",
  "Behind the scenes",
  "Product shot",
  "Product / material",
  "Tip / education",
  "Other",
] as const;

export const PLATFORM_OPTIONS = [
  { id: "FB", label: "Facebook" },
  { id: "IG", label: "Instagram" },
  { id: "TIKTOK", label: "TikTok" },
  { id: "YOUTUBE", label: "YouTube" },
  { id: "WEBSITE", label: "Website" },
] as const;

export function defaultCtaUrl(): string {
  return process.env.CONTENTOPS_CTA_URL?.trim() || "https://resiklo.com";
}