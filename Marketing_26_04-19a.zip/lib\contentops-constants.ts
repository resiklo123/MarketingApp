export const MACHINE_OPTIONS = [
  "Shredder",
  "Granulator",
  "Extrusion line",
  "Wash line",
  "Pelletizer",
  "Other",
] as const;

export const TOPIC_OPTIONS = [
  "Process spotlight",
  "Safety",
  "Customer story",
  "Behind the scenes",
  "Product / material",
  "Tip / education",
  "Other",
] as const;

export const PLATFORM_OPTIONS = [
  { id: "FB", label: "Facebook" },
  { id: "IG", label: "Instagram" },
  { id: "TIKTOK", label: "TikTok" },
  { id: "YOUTUBE", label: "YouTube" },
  { id: "WEBSITE", label: "Website" },
] as const;

export function defaultCtaUrl(): string {
  return process.env.CONTENTOPS_CTA_URL?.trim() || "https://resiklo.com";
}
