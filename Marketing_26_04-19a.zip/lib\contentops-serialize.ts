import type { Asset, Draft, Post, PostingLog } from "@prisma/client";

export type SerializedAsset = Omit<Asset, "size"> & { size: string | null };

export function serializeAsset(a: Asset): SerializedAsset {
  return {
    ...a,
    size: a.size != null ? a.size.toString() : null,
  };
}

export function serializePostDetail(post: Post & { assets: Asset[]; drafts: Draft[]; logs: PostingLog[] }) {
  return {
    ...post,
    assets: post.assets.map(serializeAsset),
    drafts: post.drafts,
    logs: post.logs,
  };
}
