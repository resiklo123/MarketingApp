import Link from "next/link";
import { ContentOpsAuthShell } from "@/components/contentops/auth-shell";

export default function ContentOpsLayout({ children }: { children: React.ReactNode }) {
  return (
    <ContentOpsAuthShell>
      <header
        style={{
          borderBottom: "1px solid var(--border)",
          background: "var(--panel)",
        }}
      >
        <div
          style={{
            maxWidth: 1100,
            margin: "0 auto",
            padding: "0.75rem 1.25rem",
            display: "flex",
            gap: "1rem",
            flexWrap: "wrap",
            alignItems: "center",
          }}
        >
          <strong>ContentOps</strong>
          <nav className="co-row" style={{ marginLeft: "auto" }}>
            <Link href="/admin/contentops">Inbox</Link>
            <Link href="/admin/contentops/new">New post</Link>
            <Link href="/">Marketing site</Link>
          </nav>
        </div>
      </header>
      <main style={{ maxWidth: 1100 }}>{children}</main>
    </ContentOpsAuthShell>
  );
}
