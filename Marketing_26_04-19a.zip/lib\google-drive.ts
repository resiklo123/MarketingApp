import { google, drive_v3 } from "googleapis";

export type IncomingDriveFile = {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  createdTime?: string | null;
  webViewLink?: string | null;
  thumbnailLink?: string | null;
};

function parseServiceAccountJson(raw: string | undefined): object {
  if (!raw || !raw.trim()) {
    throw new Error("GOOGLE_SERVICE_ACCOUNT_JSON is empty");
  }
  const trimmed = raw.trim();
  try {
    return JSON.parse(trimmed) as object;
  } catch {
    try {
      const unescaped = JSON.parse(`"${trimmed.replace(/"/g, '\\"')}"`) as string;
      return JSON.parse(unescaped) as object;
    } catch {
      throw new Error("GOOGLE_SERVICE_ACCOUNT_JSON is not valid JSON");
    }
  }
}

export function getDriveClient(): drive_v3.Drive {
  const credentials = parseServiceAccountJson(process.env.GOOGLE_SERVICE_ACCOUNT_JSON);
  const auth = new google.auth.GoogleAuth({
    credentials,
    scopes: ["https://www.googleapis.com/auth/drive"],
  });
  return google.drive({ version: "v3", auth });
}

function sanitizePathSegment(segment: string): string {
  return segment
    .replace(/[/\\?%*:|"'<>]/g, "-")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 200) || "unnamed";
}

export async function listIncomingFiles(limit = 50): Promise<IncomingDriveFile[]> {
  const folderId = process.env.DRIVE_INCOMING_FOLDER_ID;
  if (!folderId) throw new Error("DRIVE_INCOMING_FOLDER_ID is not set");
  const drive = getDriveClient();
  const res = await drive.files.list({
    q: `'${folderId}' in parents and trashed = false and mimeType != 'application/vnd.google-apps.folder'`,
    pageSize: limit,
    fields:
      "nextPageToken, files(id, name, mimeType, size, createdTime, webViewLink, thumbnailLink)",
    supportsAllDrives: true,
    includeItemsFromAllDrives: true,
  });
  return (res.data.files ?? []).map((f) => ({
    id: f.id!,
    name: f.name ?? "",
    mimeType: f.mimeType ?? "",
    size: f.size ?? undefined,
    createdTime: f.createdTime,
    webViewLink: f.webViewLink,
    thumbnailLink: f.thumbnailLink,
  }));
}

async function findOrCreateFolder(drive: drive_v3.Drive, name: string, parentId: string): Promise<string> {
  const safe = sanitizePathSegment(name);
  const existing = await drive.files.list({
    q: `'${parentId}' in parents and trashed = false and mimeType = 'application/vnd.google-apps.folder'`,
    pageSize: 200,
    fields: "files(id, name)",
    supportsAllDrives: true,
    includeItemsFromAllDrives: true,
  });
  const hit = existing.data.files?.find((f) => f.name === safe);
  if (hit?.id) return hit.id;
  const created = await drive.files.create({
    requestBody: {
      name: safe,
      mimeType: "application/vnd.google-apps.folder",
      parents: [parentId],
    },
    fields: "id",
    supportsAllDrives: true,
  });
  if (!created.data.id) throw new Error(`Failed to create folder: ${safe}`);
  return created.data.id;
}

export type PostFolderContext = {
  id: string;
  machine: string;
  topic: string;
  createdAt: Date;
};

export async function ensurePostFolder(post: PostFolderContext): Promise<string> {
  const libraryId = process.env.DRIVE_LIBRARY_FOLDER_ID;
  if (!libraryId) throw new Error("DRIVE_LIBRARY_FOLDER_ID is not set");
  const drive = getDriveClient();
  const y = post.createdAt.getUTCFullYear().toString();
  const m = String(post.createdAt.getUTCMonth() + 1).padStart(2, "0");
  const yearId = await findOrCreateFolder(drive, y, libraryId);
  const monthId = await findOrCreateFolder(drive, m, yearId);
  const machineId = await findOrCreateFolder(drive, post.machine, monthId);
  const topicId = await findOrCreateFolder(drive, post.topic, machineId);
  const postIdFolder = await findOrCreateFolder(drive, post.id, topicId);
  return postIdFolder;
}

export async function moveAndRenameFile(
  fileId: string,
  newParentId: string,
  newName: string,
): Promise<drive_v3.Schema$File> {
  const drive = getDriveClient();
  const meta = await drive.files.get({
    fileId,
    fields: "parents",
    supportsAllDrives: true,
  });
  const prevParents = (meta.data.parents ?? []).join(",");
  const updated = await drive.files.update({
    fileId,
    addParents: newParentId,
    removeParents: prevParents || undefined,
    requestBody: { name: newName },
    fields: "id, name, mimeType, size, webViewLink, thumbnailLink, parents",
    supportsAllDrives: true,
  });
  return updated.data;
}

export async function getFileMetadata(fileId: string): Promise<IncomingDriveFile> {
  const drive = getDriveClient();
  const res = await drive.files.get({
    fileId,
    fields: "id, name, mimeType, size, createdTime, webViewLink, thumbnailLink",
    supportsAllDrives: true,
  });
  const f = res.data;
  return {
    id: f.id!,
    name: f.name ?? "",
    mimeType: f.mimeType ?? "",
    size: f.size ?? undefined,
    createdTime: f.createdTime,
    webViewLink: f.webViewLink,
    thumbnailLink: f.thumbnailLink,
  };
}
