"use client";

import { MACHINE_OPTIONS, PLATFORM_OPTIONS, TOPIC_OPTIONS } from "@/lib/contentops-constants";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";

type IncomingFile = {
  id: string;
  name: string;
  mimeType: string;
  thumbnailLink?: string | null;
};

export default function ContentOpsNewPostPage() {
  const router = useRouter();
  const [files, setFiles] = useState<IncomingFile[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [machine, setMachine] = useState<string>(MACHINE_OPTIONS[0]);
  const [topic, setTopic] = useState<string>(TOPIC_OPTIONS[0]);
  const [location, setLocation] = useState("");
  const [platforms, setPlatforms] = useState<string[]>(["FB", "IG"]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/contentops/incoming", { credentials: "include" });
      const data = await res.json();
      if (!res.ok) {
        setError((data as { error?: string }).error ?? "Failed to load incoming");
        return;
      }
      setFiles((data as { files: IncomingFile[] }).files ?? []);
    } catch {
      setError("Network error loading incoming");
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  function togglePlatform(id: string) {
    setPlatforms((prev) => (prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]));
  }

  function toggleFile(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  return (
    <main className="co-stack" style={{ padding: "1.25rem" }}>
      <h1>New post</h1>
      {error ? <p style={{ color: "var(--danger)" }}>{error}</p> : null}
      <section className="co-panel co-stack">
        <h2 style={{ marginTop: 0 }}>1. Select Drive files</h2>
        <p className="co-muted">Choose one or more files that are already in the Incoming folder.</p>
        <div className="co-grid">
          {files.map((f) => {
            const isSel = selected.has(f.id);
            return (
              <button
                key={f.id}
                type="button"
                className={`co-thumb${isSel ? " selected" : ""}`}
                onClick={() => toggleFile(f.id)}
                style={{ padding: 0, cursor: "pointer", textAlign: "left", color: "inherit" }}
              >
                {f.thumbnailLink ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={f.thumbnailLink} alt="" />
                ) : (
                  <div style={{ aspectRatio: 1, display: "grid", placeItems: "center" }} className="co-muted">
                    No preview
                  </div>
                )}
                <div style={{ padding: "0.35rem 0.5rem", fontSize: "0.8rem" }}>{f.name}</div>
              </button>
            );
          })}
        </div>
      </section>

      <section className="co-panel co-stack">
        <h2 style={{ marginTop: 0 }}>2. Metadata</h2>
        <label className="co-stack">
          <span className="co-muted">Machine</span>
          <select className="co-select" value={machine} onChange={(e) => setMachine(e.target.value)}>
            {MACHINE_OPTIONS.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>
        </label>
        <label className="co-stack">
          <span className="co-muted">Topic</span>
          <select className="co-select" value={topic} onChange={(e) => setTopic(e.target.value)}>
            {TOPIC_OPTIONS.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </label>
        <label className="co-stack">
          <span className="co-muted">Location (optional)</span>
          <input className="co-input" value={location} onChange={(e) => setLocation(e.target.value)} />
        </label>
        <div className="co-stack">
          <span className="co-muted">Platforms</span>
          <div className="co-row">
            {PLATFORM_OPTIONS.map((p) => (
              <label key={p.id} className="co-row">
                <input
                  type="checkbox"
                  checked={platforms.includes(p.id)}
                  onChange={() => togglePlatform(p.id)}
                />
                {p.label}
              </label>
            ))}
          </div>
        </div>
      </section>

      <div className="co-row">
        <button
          type="button"
          className="co-btn primary"
          disabled={busy || selected.size === 0 || platforms.length === 0}
          onClick={async () => {
            setBusy(true);
            setError(null);
            try {
              const res = await fetch("/api/contentops/posts", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify({
                  machine,
                  topic,
                  location: location.trim() || null,
                  platforms,
                  driveFileIds: Array.from(selected),
                }),
              });
              const data = await res.json();
              if (!res.ok) {
                setError((data as { error?: string }).error ?? "Create failed");
                setBusy(false);
                return;
              }
              const postId = (data as { postId: string }).postId;
              router.push(`/admin/contentops/${postId}`);
            } catch {
              setError("Network error");
            } finally {
              setBusy(false);
            }
          }}
        >
          {busy ? "Processing…" : "Create post & drafts"}
        </button>
        <Link href="/admin/contentops">Cancel</Link>
      </div>
    </main>
  );
}
