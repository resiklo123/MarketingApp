import path from "node:path";
import { PostStatus, type Prisma } from "@prisma/client";
import { defaultCtaUrl } from "@/lib/contentops-constants";
import { ensurePostFolder, getFileMetadata, moveAndRenameFile } from "@/lib/google-drive";
import { generateDraftsJson, type DraftsJson } from "@/lib/openai-drafts";
import { prisma } from "@/lib/prisma";
import { getOptionalRedis } from "@/lib/redis";
import { sendTelegramDraftReadyMessage } from "@/lib/telegram";

function buildFinalName(postId: string, originalName: string): string {
  const ext = path.extname(originalName);
  const base = path.basename(originalName, ext).replace(/[/\\?%*:|"'<>]/g, "-").slice(0, 120);
  return `${postId}_${base || "asset"}${ext}`;
}

function stubDraftsJson(): DraftsJson {
  return {
    fb: { caption: "TEST_MODE Facebook caption", hashtags: "#resiklo #test" },
    ig: { caption: "TEST_MODE Instagram caption", hashtags: "#resiklo #test" },
    tiktok: { caption: "TEST_MODE TikTok caption", hashtags: "#resiklo #test" },
    youtube: { title: "TEST_MODE YouTube title", description: "TEST_MODE YouTube description" },
    website: { snippet: "TEST_MODE website snippet" },
  };
}

function draftCreatesFromJson(postId: string, platforms: string[], data: DraftsJson): Prisma.DraftCreateManyInput[] {
  const rows: Prisma.DraftCreateManyInput[] = [];
  const upper = new Set(platforms.map((p) => p.toUpperCase()));
  if (upper.has("FB")) {
    rows.push({
      postId,
      platform: "FB",
      caption: data.fb.caption,
      hashtags: data.fb.hashtags,
      version: 1,
    });
  }
  if (upper.has("IG")) {
    rows.push({
      postId,
      platform: "IG",
      caption: data.ig.caption,
      hashtags: data.ig.hashtags,
      version: 1,
    });
  }
  if (upper.has("TIKTOK")) {
    rows.push({
      postId,
      platform: "TIKTOK",
      caption: data.tiktok.caption,
      hashtags: data.tiktok.hashtags,
      version: 1,
    });
  }
  if (upper.has("YOUTUBE")) {
    rows.push({
      postId,
      platform: "YOUTUBE",
      title: data.youtube.title,
      description: data.youtube.description,
      version: 1,
    });
  }
  if (upper.has("WEBSITE")) {
    rows.push({
      postId,
      platform: "WEBSITE",
      caption: data.website.snippet,
      version: 1,
    });
  }
  return rows;
}

export async function processNewContentOpsPost(input: {
  machine: string;
  topic: string;
  location?: string | null;
  platforms: string[];
  driveFileIds: string[];
}): Promise<{ postId: string }> {
  const testMode = process.env.CONTENTOPS_TEST_MODE === "true";
  const redis = getOptionalRedis();
  void redis?.incr("contentops:posts_created").catch(() => undefined);

  const post = await prisma.post.create({
    data: {
      machine: input.machine,
      topic: input.topic,
      location: input.location ?? null,
      platforms: input.platforms.map((p) => p.toUpperCase()),
      status: PostStatus.PROCESSING,
    },
  });

  try {
    if (testMode) {
      await prisma.asset.createMany({
        data: input.driveFileIds.map((driveFileId, i) => ({
          postId: post.id,
          driveFileId,
          originalName: `test-asset-${i + 1}.jpg`,
          finalName: `test-asset-${i + 1}.jpg`,
          mimeType: "image/jpeg",
          size: null,
          webViewLink: null,
          thumbnailLink: null,
        })),
      });
      const draftsJson = stubDraftsJson();
      const draftRows = draftCreatesFromJson(post.id, input.platforms, draftsJson);
      if (draftRows.length) {
        await prisma.draft.createMany({ data: draftRows });
      }
      await prisma.post.update({
        where: { id: post.id },
        data: { status: PostStatus.DRAFT_READY },
      });
      return { postId: post.id };
    }

    const metas = await Promise.all(input.driveFileIds.map((id) => getFileMetadata(id)));
    const folderId = await ensurePostFolder({
      id: post.id,
      machine: input.machine,
      topic: input.topic,
      createdAt: post.createdAt,
    });

    const moved: { meta: (typeof metas)[0]; finalName: string; afterMove: Awaited<ReturnType<typeof moveAndRenameFile>> }[] =
      [];
    for (let i = 0; i < metas.length; i++) {
      const meta = metas[i]!;
      const finalName = buildFinalName(post.id, meta.name);
      const afterMove = await moveAndRenameFile(meta.id, folderId, finalName);
      moved.push({ meta, finalName, afterMove });
    }

    await prisma.asset.createMany({
      data: moved.map(({ meta, finalName, afterMove }) => ({
        postId: post.id,
        driveFileId: afterMove.id ?? meta.id,
        originalName: meta.name,
        finalName,
        mimeType: afterMove.mimeType ?? meta.mimeType,
        size: afterMove.size != null ? BigInt(afterMove.size) : meta.size != null ? BigInt(meta.size) : null,
        webViewLink: afterMove.webViewLink ?? meta.webViewLink ?? null,
        thumbnailLink: afterMove.thumbnailLink ?? meta.thumbnailLink ?? null,
      })),
    });

    const draftsJson = await generateDraftsJson({
      machine: input.machine,
      topic: input.topic,
      location: input.location,
      ctaUrl: defaultCtaUrl(),
      platforms: input.platforms.map((p) => p.toUpperCase()),
    });
    const draftRows = draftCreatesFromJson(post.id, input.platforms, draftsJson);
    if (draftRows.length) {
      await prisma.draft.createMany({ data: draftRows });
    }

    await prisma.post.update({
      where: { id: post.id },
      data: { status: PostStatus.DRAFT_READY },
    });

    try {
      await sendTelegramDraftReadyMessage({
        postId: post.id,
        machine: input.machine,
        topic: input.topic,
      });
    } catch (e) {
      console.error("[contentops] Telegram notify failed (post still DRAFT_READY):", e);
    }

    return { postId: post.id };
  } catch (e) {
    await prisma.post.update({
      where: { id: post.id },
      data: { status: PostStatus.FAILED },
    });
    throw e;
  }
}
