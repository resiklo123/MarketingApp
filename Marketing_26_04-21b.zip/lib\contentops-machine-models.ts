import { prisma } from "@/lib/prisma";
import { DEFAULT_MACHINE_MODELS } from "@/lib/contentops-constants";

export async function ensureDefaultMachineModelsSeeded(): Promise<void> {
  const tasks: Promise<unknown>[] = [];
  for (const [family, models] of Object.entries(DEFAULT_MACHINE_MODELS)) {
    for (const model of models) {
      tasks.push(
        prisma.machineModelOption.upsert({
          where: { family_model: { family, model } },
          create: { family, model, isActive: true },
          update: { isActive: true },
        }),
      );
    }
  }
  await Promise.all(tasks);
}
