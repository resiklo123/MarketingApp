"use client";

import {
  BALER_MODEL_OPTIONS,
  MACHINE_FAMILY_OPTIONS,
  PLATFORM_OPTIONS,
  TOPIC_OPTIONS,
} from "@/lib/contentops-constants";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import { LoadingOverlay } from "@/components/contentops/loading-overlay";

type IncomingFile = {
  id: string;
  name: string;
  mimeType: string;
  webViewLink?: string | null;
};

function extLabel(name: string): string {
  const parts = name.split(".");
  if (parts.length < 2) return "FILE";
  return parts.at(-1)?.slice(0, 6).toUpperCase() || "FILE";
}

export default function ContentOpsNewPostPage() {
  const router = useRouter();
  const [files, setFiles] = useState<IncomingFile[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const [machineFamily, setMachineFamily] = useState<string>(MACHINE_FAMILY_OPTIONS[0]);
  const [machineModel, setMachineModel] = useState<string>("");
  const [knownModels, setKnownModels] = useState<string[]>([]);

  const [balerPreset, setBalerPreset] = useState<string>(BALER_MODEL_OPTIONS[0]);
  const [customBalerModel, setCustomBalerModel] = useState<string>("");

  const [topic, setTopic] = useState<string>(TOPIC_OPTIONS[0]);
  const [location, setLocation] = useState("");
  const [platforms, setPlatforms] = useState<string[]>(["FB", "IG"]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [loadingFiles, setLoadingFiles] = useState(true);
  const [loadedCount, setLoadedCount] = useState<number | null>(null);

  const effectiveMachineModel = useMemo(() => {
    const isBaler = machineFamily.toLowerCase() === "balers" || machineFamily.toLowerCase() === "baler";
    if (isBaler) {
      if (balerPreset === "Other") return customBalerModel.trim() || null;
      return balerPreset;
    }
    return machineModel.trim() || null;
  }, [machineFamily, machineModel, balerPreset, customBalerModel]);

  const load = useCallback(async () => {
    setLoadingFiles(true);
    setError(null);
    try {
      const res = await fetch("/api/contentops/incoming", { credentials: "include" });
      const data = await res.json();
      if (!res.ok) {
        setError((data as { error?: string }).error ?? "Failed to load incoming");
        setFiles([]);
        setLoadedCount(0);
        return;
      }
      const incoming = (data as { files: IncomingFile[] }).files ?? [];
      setFiles(incoming);
      setLoadedCount(incoming.length);
      setSelected((prev) => {
        const valid = new Set(incoming.map((f) => f.id));
        return new Set(Array.from(prev).filter((id) => valid.has(id)));
      });
    } catch {
      setError("Network error loading incoming");
      setFiles([]);
      setLoadedCount(0);
    } finally {
      setLoadingFiles(false);
    }
  }, []);

  const loadKnownModels = useCallback(async (family: string) => {
    try {
      const res = await fetch(`/api/contentops/machine-models?family=${encodeURIComponent(family)}&t=${Date.now()}`, {
        credentials: "include",
        cache: "no-store",
      });
      const data = (await res.json()) as { models?: string[] };
      if (res.ok) setKnownModels(data.models ?? []);
      else setKnownModels([]);
    } catch {
      setKnownModels([]);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    void loadKnownModels(machineFamily);
    setMachineModel("");
  }, [machineFamily, loadKnownModels]);

  function togglePlatform(id: string) {
    setPlatforms((prev) => (prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]));
  }

  function toggleFile(id: string) {
    if (loadingFiles || busy) return;
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  const isBaler = machineFamily.toLowerCase() === "balers" || machineFamily.toLowerCase() === "baler";

  return (
    <main className="co-stack" style={{ padding: "1.25rem", position: "relative" }}>
      <LoadingOverlay open={busy} text="Creating post, moving files, generating drafts..." fullscreen />

      <div className="co-row" style={{ justifyContent: "space-between", width: "100%" }}>
        <h1 style={{ margin: 0 }}>New post</h1>
        <button type="button" className="co-btn" onClick={() => void load()} disabled={loadingFiles || busy}>
          Refresh
        </button>
      </div>

      {error ? <p style={{ color: "var(--danger)", fontWeight: 600 }}>{error}</p> : null}

      <section className="co-panel co-stack" style={{ position: "relative" }}>
        <LoadingOverlay open={loadingFiles} text="Loading incoming files..." />

        <h2 style={{ marginTop: 0 }}>1. Select Drive files</h2>
        <p className="co-muted">Choose one or more files already in Incoming folder.</p>
        {!loadingFiles && loadedCount !== null ? <p className="co-muted">Loaded {loadedCount} files.</p> : null}
        {!loadingFiles && files.length === 0 ? (
          <div className="co-empty-state">
            <p>No files found in Incoming folder. Upload to Drive Incoming then click Refresh.</p>
          </div>
        ) : null}

        <div className="co-grid">
          {(loadingFiles ? Array.from({ length: 8 }) : files).map((f, index) => {
            if (loadingFiles) return <div key={`skeleton-${index}`} className="co-thumb co-skeleton" aria-hidden="true" />;
            const item = f as IncomingFile;
            const isSel = selected.has(item.id);
            return (
              <div key={item.id} className={`co-thumb${isSel ? " selected" : ""}`}>
                <button
                  type="button"
                  onClick={() => toggleFile(item.id)}
                  style={{ all: "unset", display: "block", cursor: "pointer" }}
                  disabled={busy || loadingFiles}
                >
                  {item.mimeType.startsWith("image/") ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={`/api/contentops/drive/file?id=${encodeURIComponent(item.id)}`} alt={item.name} />
                  ) : (
                    <div className="co-file-placeholder">{extLabel(item.name)}</div>
                  )}
                </button>

                <div style={{ padding: "0.35rem 0.5rem", fontSize: "0.8rem" }}>
                  <div className="co-row" style={{ justifyContent: "space-between", alignItems: "flex-start" }}>
                    <strong style={{ maxWidth: "80%", wordBreak: "break-word" }}>{item.name}</strong>
                    {isSel ? <span className="co-check-pill">Selected</span> : null}
                  </div>
                  {item.webViewLink ? (
                    <a
                      href={item.webViewLink}
                      target="_blank"
                      rel="noreferrer"
                      onClick={(e) => e.stopPropagation()}
                    >
                      Open in Drive ↗
                    </a>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="co-panel co-stack">
        <h2 style={{ marginTop: 0 }}>2. Metadata</h2>

        <label className="co-stack">
          <span className="co-muted">Machine family</span>
          <select className="co-select" value={machineFamily} onChange={(e) => setMachineFamily(e.target.value)} disabled={busy}>
            {MACHINE_FAMILY_OPTIONS.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>
        </label>

        {isBaler ? (
          <>
            <label className="co-stack">
              <span className="co-muted">Machine model/type</span>
              <select className="co-select" value={balerPreset} onChange={(e) => setBalerPreset(e.target.value)} disabled={busy}>
                {BALER_MODEL_OPTIONS.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
            </label>
            {balerPreset === "Other" ? (
              <label className="co-stack">
                <span className="co-muted">Custom baler model</span>
                <input className="co-input" value={customBalerModel} onChange={(e) => setCustomBalerModel(e.target.value)} disabled={busy} />
              </label>
            ) : null}
          </>
        ) : (
          <>
            <label className="co-stack">
              <span className="co-muted">
                Machine model/type (type or choose suggestion{knownModels.length > 0 ? "" : "s"})
              </span>
              <input
                className="co-input"
                list="machineModelOptions"
                value={machineModel}
                onChange={(e) => setMachineModel(e.target.value)}
                placeholder="Optional"
                disabled={busy}
              />
              <datalist id="machineModelOptions">
                {knownModels.map((m) => (
                  <option key={m} value={m} />
                ))}
              </datalist>
            </label>
          </>
        )}

        <label className="co-stack">
          <span className="co-muted">Topic</span>
          <select className="co-select" value={topic} onChange={(e) => setTopic(e.target.value)} disabled={busy}>
            {TOPIC_OPTIONS.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
        </label>

        <label className="co-stack">
          <span className="co-muted">Location (optional)</span>
          <input className="co-input" value={location} onChange={(e) => setLocation(e.target.value)} disabled={busy} />
        </label>

        <div className="co-stack">
          <span className="co-muted">Platforms</span>
          <div className="co-row">
            {PLATFORM_OPTIONS.map((p) => (
              <label key={p.id} className="co-row">
                <input type="checkbox" checked={platforms.includes(p.id)} onChange={() => togglePlatform(p.id)} disabled={busy} />
                {p.label}
              </label>
            ))}
          </div>
        </div>
      </section>

      <div className="co-row">
        <button
          type="button"
          className="co-btn primary"
          disabled={busy || loadingFiles}
          onClick={async () => {
            if (selected.size === 0) {
              setError("Select at least 1 Drive file before creating a post.");
              return;
            }
            if (platforms.length === 0) {
              setError("Select at least 1 platform before creating a post.");
              return;
            }

            setBusy(true);
            setError(null);
            try {
              const res = await fetch("/api/contentops/posts", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify({
                  machineFamily,
                  machineModel: effectiveMachineModel,
                  topic,
                  location: location.trim() || null,
                  platforms,
                  driveFileIds: Array.from(selected),
                }),
              });
              const data = await res.json();
              if (!res.ok) {
                setError((data as { error?: string }).error ?? "Create failed");
                return;
              }
              await loadKnownModels(machineFamily);
              router.push(`/admin/contentops/${(data as { postId: string }).postId}`);
            } catch {
              setError("Network error");
            } finally {
              setBusy(false);
            }
          }}
        >
          {busy ? "Processing..." : "Create post & drafts"}
        </button>
      </div>
    </main>
  );
}
