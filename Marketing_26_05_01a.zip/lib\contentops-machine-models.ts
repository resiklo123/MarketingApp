import { prisma } from "@/lib/prisma";
import { DEFAULT_MACHINE_MODELS } from "@/lib/contentops-constants";

export async function ensureDefaultMachineModelsSeeded(): Promise<void> {
  const existing = await prisma.machineModelOption.findMany({
    select: { family: true, model: true },
  });
  const seen = new Set(existing.map((r) => `${r.family}\0${r.model}`));

  const missing: { family: string; model: string; isActive: boolean }[] = [];
  const pendingKeys = new Set<string>();

  for (const [family, models] of Object.entries(DEFAULT_MACHINE_MODELS)) {
    for (const model of models) {
      const key = `${family}\0${model}`;
      if (seen.has(key) || pendingKeys.has(key)) continue;
      pendingKeys.add(key);
      missing.push({ family, model, isActive: true });
    }
  }

  if (missing.length === 0) return;

  await prisma.machineModelOption.createMany({ data: missing });
}
