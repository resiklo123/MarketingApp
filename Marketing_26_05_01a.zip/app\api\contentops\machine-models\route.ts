import { NextResponse } from "next/server";
import { assertContentOpsRequest } from "@/lib/contentops-auth";
import { ensureDefaultMachineModelsSeeded } from "@/lib/contentops-machine-models";
import { prisma } from "@/lib/prisma";

const noStoreHeaders = { "Cache-Control": "no-store, max-age=0" } as const;

export async function GET(request: Request) {
  try {
    await assertContentOpsRequest(request);
  } catch (e) {
    const code = (e as Error & { statusCode?: number }).statusCode;
    if (code === 401) {
      return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 });
    }
    const body: { ok: false; error: "server_error"; message?: string } = { ok: false, error: "server_error" };
    if (process.env.NODE_ENV === "development") {
      body.message = (e as Error).message;
    }
    return NextResponse.json(body, { status: 500 });
  }

  const url = new URL(request.url);
  const family =
    url.searchParams.get("family")?.trim() ?? url.searchParams.get("machineFamily")?.trim() ?? "";

  try {
    try {
      await ensureDefaultMachineModelsSeeded();
    } catch (seedErr) {
      console.error("[contentops] ensureDefaultMachineModelsSeeded failed:", seedErr);
    }

    if (!family) {
      return NextResponse.json(
        { ok: true, machineFamily: "", models: [] as string[] },
        { headers: noStoreHeaders },
      );
    }

    const rows = await prisma.machineModelOption.findMany({
      where: { family, isActive: true },
      orderBy: { model: "asc" },
      select: { model: true },
    });

    return NextResponse.json(
      {
        ok: true,
        machineFamily: family,
        models: rows.map((r: { model: string }) => r.model),
      },
      { headers: noStoreHeaders },
    );
  } catch (err) {
    console.error("[contentops] GET /machine-models failed:", err);
    const body: { ok: false; error: "server_error"; message?: string } = { ok: false, error: "server_error" };
    if (process.env.NODE_ENV === "development") {
      body.message = (err as Error).message;
    }
    return NextResponse.json(body, { status: 500 });
  }
}
