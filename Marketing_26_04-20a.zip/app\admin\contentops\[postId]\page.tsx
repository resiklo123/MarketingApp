"use client";

import { CopyButton } from "@/components/contentops/copy-button";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useCallback, useEffect, useState } from "react";

type Draft = {
  id: string;
  platform: string;
  title: string | null;
  caption: string | null;
  hashtags: string | null;
  description: string | null;
};

type Asset = {
  id: string;
  driveFileId: string;
  originalName: string;
  finalName: string;
  mimeType: string;
  webViewLink: string | null;
  thumbnailLink: string | null;
};

type PostDetail = {
  id: string;
  machine: string;
  topic: string;
  location: string | null;
  platforms: string[];
  status: string;
  createdAt: string;
  assets: Asset[];
  drafts: Draft[];
};

function extLabel(name: string): string {
  const parts = name.split(".");
  if (parts.length < 2) return "FILE";
  return parts.at(-1)?.slice(0, 6).toUpperCase() || "FILE";
}

export default function ContentOpsPostDetailPage() {
  const params = useParams();
  const postId = params.postId as string;
  const [post, setPost] = useState<PostDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [statusChoice, setStatusChoice] = useState<string>("DRAFT");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    try {
      const res = await fetch(`/api/contentops/posts/${postId}`, { credentials: "include" });
      const data = await res.json();
      if (!res.ok) {
        setError((data as { error?: string }).error ?? "Failed to load");
        setPost(null);
        return;
      }
      const p = data as PostDetail;
      setPost(p);
      setStatusChoice(p.status === "DRAFT_READY" ? "DRAFT" : p.status);
    } catch {
      setError("Network error");
    }
  }, [postId]);

  useEffect(() => {
    void load();
  }, [load]);

  if (!post && !error) {
    return (
      <main style={{ padding: "1.25rem" }}>
        <p>Loading…</p>
      </main>
    );
  }

  if (error || !post) {
    return (
      <main style={{ padding: "1.25rem" }} className="co-stack">
        <p style={{ color: "var(--danger)" }}>{error}</p>
        <Link href="/admin/contentops">Back</Link>
      </main>
    );
  }

  return (
    <main className="co-stack" style={{ padding: "1.25rem" }}>
      <div className="co-row" style={{ justifyContent: "space-between", width: "100%" }}>
        <h1 style={{ margin: 0 }}>Post {post.id}</h1>
        <Link href="/admin/contentops">Inbox</Link>
      </div>
      <p className="co-muted">
        {post.machine} / {post.topic}
        {post.location ? ` — ${post.location}` : ""}
      </p>
      <p>
        Status: <strong>{post.status}</strong>
      </p>

      <section className="co-panel co-stack">
        <h2 style={{ marginTop: 0 }}>Update status</h2>
        <div className="co-row">
          <select className="co-select" value={statusChoice} onChange={(e) => setStatusChoice(e.target.value)}>
            <option value="DRAFT">DRAFT</option>
            <option value="DRAFT_READY">DRAFT_READY</option>
            <option value="POSTED">POSTED</option>
            <option value="ARCHIVED">ARCHIVED</option>
            <option value="FAILED">FAILED</option>
            <option value="PROCESSING">PROCESSING</option>
          </select>
          <button
            type="button"
            className="co-btn primary"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              try {
                const res = await fetch(`/api/contentops/posts/${postId}/status`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  credentials: "include",
                  body: JSON.stringify({ status: statusChoice }),
                });
                if (!res.ok) {
                  const j = await res.json().catch(() => ({}));
                  setError((j as { error?: string }).error ?? "Update failed");
                } else {
                  await load();
                }
              } finally {
                setBusy(false);
              }
            }}
          >
            Save status
          </button>
        </div>
      </section>

      <section className="co-panel co-stack">
        <h2 style={{ marginTop: 0 }}>Assets</h2>
        <div className="co-grid">
          {post.assets.map((a) => (
            <div key={a.id} className="co-thumb">
              {a.mimeType.startsWith("image/") ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={`/api/contentops/drive/file?id=${encodeURIComponent(a.driveFileId)}`} alt={a.finalName} />
              ) : (
                <div className="co-file-placeholder">{extLabel(a.finalName)}</div>
              )}
              <div style={{ padding: "0.35rem 0.5rem", fontSize: "0.8rem" }}>
                <div>{a.finalName}</div>
                {a.webViewLink ? (
                  <a href={a.webViewLink} target="_blank" rel="noreferrer">
                    Drive
                  </a>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="co-panel co-stack">
        <h2 style={{ marginTop: 0 }}>Drafts</h2>
        {post.drafts.map((d) => {
          const blocks: { label: string; text: string }[] = [];
          if (d.title) blocks.push({ label: "Title", text: d.title });
          if (d.caption) blocks.push({ label: "Caption / snippet", text: d.caption });
          if (d.hashtags) blocks.push({ label: "Hashtags", text: d.hashtags });
          if (d.description) blocks.push({ label: "Description", text: d.description });
          const joined = blocks.map((b) => `${b.label}:\n${b.text}`).join("\n\n");
          return (
            <div key={d.id} className="co-stack" style={{ borderTop: "1px solid var(--border)", paddingTop: "0.75rem" }}>
              <div className="co-row" style={{ justifyContent: "space-between" }}>
                <strong>{d.platform}</strong>
                {joined ? <CopyButton text={joined} /> : null}
              </div>
              {d.title ? (
                <label className="co-stack">
                  <span className="co-muted">Title</span>
                  <textarea className="co-textarea" readOnly value={d.title} />
                </label>
              ) : null}
              {d.caption ? (
                <label className="co-stack">
                  <span className="co-muted">{d.platform === "WEBSITE" ? "Snippet" : "Caption"}</span>
                  <textarea className="co-textarea" readOnly value={d.caption} />
                </label>
              ) : null}
              {d.hashtags ? (
                <label className="co-stack">
                  <span className="co-muted">Hashtags</span>
                  <textarea className="co-textarea" readOnly value={d.hashtags} />
                </label>
              ) : null}
              {d.description ? (
                <label className="co-stack">
                  <span className="co-muted">Description</span>
                  <textarea className="co-textarea" readOnly value={d.description} />
                </label>
              ) : null}
            </div>
          );
        })}
      </section>
    </main>
  );
}