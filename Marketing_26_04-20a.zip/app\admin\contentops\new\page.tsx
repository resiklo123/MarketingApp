﻿"use client";

import { MACHINE_OPTIONS, PLATFORM_OPTIONS, TOPIC_OPTIONS } from "@/lib/contentops-constants";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";

type IncomingFile = {
  id: string;
  name: string;
  mimeType: string;
};

function extLabel(name: string): string {
  const parts = name.split(".");
  if (parts.length < 2) return "FILE";
  return parts.at(-1)?.slice(0, 6).toUpperCase() || "FILE";
}

export default function ContentOpsNewPostPage() {
  const router = useRouter();
  const [files, setFiles] = useState<IncomingFile[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [machine, setMachine] = useState<string>(MACHINE_OPTIONS[0]);
  const [topic, setTopic] = useState<string>(TOPIC_OPTIONS[0]);
  const [location, setLocation] = useState("");
  const [platforms, setPlatforms] = useState<string[]>(["FB", "IG"]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [loadingFiles, setLoadingFiles] = useState(true);
  const [loadedCount, setLoadedCount] = useState<number | null>(null);

  const load = useCallback(async () => {
    setLoadingFiles(true);
    setError(null);
    try {
      const res = await fetch("/api/contentops/incoming", { credentials: "include" });
      const data = await res.json();
      if (!res.ok) {
        setError((data as { error?: string }).error ?? "Failed to load incoming");
        setFiles([]);
        setLoadedCount(0);
        return;
      }
      const incoming = (data as { files: IncomingFile[] }).files ?? [];
      setFiles(incoming);
      setLoadedCount(incoming.length);
      setSelected((prev) => {
        const valid = new Set(incoming.map((f) => f.id));
        return new Set(Array.from(prev).filter((id) => valid.has(id)));
      });
    } catch {
      setError("Network error loading incoming");
      setFiles([]);
      setLoadedCount(0);
    } finally {
      setLoadingFiles(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  function togglePlatform(id: string) {
    setPlatforms((prev) => (prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]));
  }

  function toggleFile(id: string) {
    if (loadingFiles || busy) return;
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  return (
    <main className="co-stack" style={{ padding: "1.25rem", position: "relative" }}>
      {busy ? (
        <div className="co-loading-overlay" role="status" aria-live="polite">
          <div className="co-spinner" />
          <p>Processing files and generating drafts…</p>
        </div>
      ) : null}

      <div className="co-row" style={{ justifyContent: "space-between", width: "100%" }}>
        <h1 style={{ margin: 0 }}>New post</h1>
        <button type="button" className="co-btn" onClick={() => void load()} disabled={loadingFiles || busy}>
          Refresh
        </button>
      </div>

      {error ? <p style={{ color: "var(--danger)" }}>{error}</p> : null}

      <section className="co-panel co-stack" style={{ position: "relative" }}>
        {loadingFiles ? (
          <div className="co-loading-overlay" role="status" aria-live="polite">
            <div className="co-spinner" />
            <p>Loading incoming files…</p>
          </div>
        ) : null}

        <h2 style={{ marginTop: 0 }}>1. Select Drive files</h2>
        <p className="co-muted">Choose one or more files that are already in the Incoming folder.</p>
        {!loadingFiles && loadedCount !== null ? <p className="co-muted">Loaded {loadedCount} files.</p> : null}
        {!loadingFiles && files.length === 0 ? (
          <div className="co-empty-state">
            <p>No files found in Incoming folder. Upload to Drive Incoming then click Refresh.</p>
          </div>
        ) : null}

        <div className="co-grid">
          {(loadingFiles ? Array.from({ length: 8 }) : files).map((f, index) => {
            if (loadingFiles) {
              return <div key={`skeleton-${index}`} className="co-thumb co-skeleton" aria-hidden="true" />;
            }
            const item = f as IncomingFile;
            const isSel = selected.has(item.id);
            return (
              <button
                key={item.id}
                type="button"
                className={`co-thumb${isSel ? " selected" : ""}`}
                onClick={() => toggleFile(item.id)}
                style={{ padding: 0, cursor: "pointer", textAlign: "left", color: "inherit" }}
                disabled={busy || loadingFiles}
              >
                {item.mimeType.startsWith("image/") ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={`/api/contentops/drive/file?id=${encodeURIComponent(item.id)}`} alt={item.name} />
                ) : (
                  <div className="co-file-placeholder">{extLabel(item.name)}</div>
                )}
                <div style={{ padding: "0.35rem 0.5rem", fontSize: "0.8rem" }}>{item.name}</div>
              </button>
            );
          })}
        </div>
      </section>

      <section className="co-panel co-stack">
        <h2 style={{ marginTop: 0 }}>2. Metadata</h2>
        <label className="co-stack">
          <span className="co-muted">Machine</span>
          <select className="co-select" value={machine} onChange={(e) => setMachine(e.target.value)} disabled={busy}>
            {MACHINE_OPTIONS.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>
        </label>
        <label className="co-stack">
          <span className="co-muted">Topic</span>
          <select className="co-select" value={topic} onChange={(e) => setTopic(e.target.value)} disabled={busy}>
            {TOPIC_OPTIONS.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </label>
        <label className="co-stack">
          <span className="co-muted">Location (optional)</span>
          <input className="co-input" value={location} onChange={(e) => setLocation(e.target.value)} disabled={busy} />
        </label>
        <div className="co-stack">
          <span className="co-muted">Platforms</span>
          <div className="co-row">
            {PLATFORM_OPTIONS.map((p) => (
              <label key={p.id} className="co-row">
                <input
                  type="checkbox"
                  checked={platforms.includes(p.id)}
                  onChange={() => togglePlatform(p.id)}
                  disabled={busy}
                />
                {p.label}
              </label>
            ))}
          </div>
        </div>
      </section>

      <div className="co-row">
        <button
          type="button"
          className="co-btn primary"
          disabled={busy || loadingFiles || selected.size === 0 || platforms.length === 0}
          onClick={async () => {
            setBusy(true);
            setError(null);
            try {
              const res = await fetch("/api/contentops/posts", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify({
                  machine,
                  topic,
                  location: location.trim() || null,
                  platforms,
                  driveFileIds: Array.from(selected),
                }),
              });
              const data = await res.json();
              if (!res.ok) {
                setError((data as { error?: string }).error ?? "Create failed");
                return;
              }
              const createdPostId = (data as { postId: string }).postId;
              router.push(`/admin/contentops/${createdPostId}`);
            } catch {
              setError("Network error");
            } finally {
              setBusy(false);
            }
          }}
        >
          {busy ? "Processing…" : "Create post & drafts"}
        </button>
        <Link href="/admin/contentops">Cancel</Link>
      </div>
    </main>
  );
}
