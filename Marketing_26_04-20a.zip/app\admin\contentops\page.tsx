﻿"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";

type IncomingFile = {
  id: string;
  name: string;
  mimeType: string;
  webViewLink?: string | null;
};

function extLabel(name: string): string {
  const parts = name.split(".");
  if (parts.length < 2) return "FILE";
  return parts.at(-1)?.slice(0, 6).toUpperCase() || "FILE";
}

export default function ContentOpsInboxPage() {
  const [files, setFiles] = useState<IncomingFile[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/contentops/incoming", { credentials: "include" });
      const data = await res.json();
      if (!res.ok) {
        setError((data as { error?: string }).error ?? "Failed to load");
        setFiles([]);
        return;
      }
      setFiles((data as { files: IncomingFile[] }).files ?? []);
    } catch {
      setError("Network error");
      setFiles([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <main className="co-stack" style={{ padding: "1.25rem" }}>
      <div className="co-row" style={{ justifyContent: "space-between", width: "100%" }}>
        <h1 style={{ margin: 0 }}>Incoming (Google Drive)</h1>
        <button type="button" className="co-btn" onClick={() => void load()} disabled={loading}>
          Refresh
        </button>
      </div>
      <p className="co-muted">
        Files listed here are already in Drive — nothing is uploaded through Vercel. Select them when creating a{" "}
        <Link href="/admin/contentops/new">new post</Link>.
      </p>
      {loading ? <p>Loading…</p> : null}
      {error ? <p style={{ color: "var(--danger)" }}>{error}</p> : null}
      {!loading && files && files.length === 0 ? <p className="co-muted">No files in the incoming folder.</p> : null}
      <div className="co-grid">
        {(files ?? []).map((f) => (
          <div key={f.id} className="co-thumb">
            {f.mimeType.startsWith("image/") ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={`/api/contentops/drive/file?id=${encodeURIComponent(f.id)}`} alt={f.name} />
            ) : (
              <div className="co-file-placeholder">{extLabel(f.name)}</div>
            )}
            <div style={{ padding: "0.35rem 0.5rem", fontSize: "0.8rem" }}>
              <div style={{ wordBreak: "break-word" }}>{f.name}</div>
              {f.webViewLink ? (
                <a href={f.webViewLink} target="_blank" rel="noreferrer">
                  Open in Drive
                </a>
              ) : null}
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
